# Chessmate
IT-Projektarbeit: Schachspiel

Ladet euch die Desktop Version herunter und erstellt euch einen Datei auf eurem PC.
Git Desktop sollte euch automatisch vorschlagen Visual Studio zu verwenden.
Dort bearbeitet ihr es. Weiteres werden wir gemeinsam erfahren!

Viel Spaß!
